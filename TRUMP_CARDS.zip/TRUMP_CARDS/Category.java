package TRUMP_CARDS;


public class Category {
    
String name;
int value;
boolean higher_value;

public Category(String name, int value, boolean higher_value)
{
    this.name = name;
    this.value = value;
    this.higher_value = higher_value;
}



}
