package TRUMP_CARDS;

import java.util.*;

class Card {
    List<Category> categories;

    public Card(List<Category> categories) {
        this.categories = categories;
    }

}